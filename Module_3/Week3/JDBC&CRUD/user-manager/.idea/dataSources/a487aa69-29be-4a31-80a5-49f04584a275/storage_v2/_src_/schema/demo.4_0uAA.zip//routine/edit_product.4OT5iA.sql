create
    definer = root@localhost procedure edit_product(IN id int, IN productcode varchar(10), IN productname varchar(30))
begin
	update  products set products.productcode = productcode, products.productname = productname where products.id = id;
end;

