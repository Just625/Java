create
    definer = root@localhost procedure delete_product(IN productid int)
begin
	delete from products where products.id = productid;
end;

