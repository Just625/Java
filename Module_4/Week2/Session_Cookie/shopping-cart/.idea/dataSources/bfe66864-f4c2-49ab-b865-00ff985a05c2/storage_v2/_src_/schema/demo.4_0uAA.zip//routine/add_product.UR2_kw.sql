create
    definer = root@localhost procedure add_product(IN codes varchar(10), IN productName varchar(30),
                                                   IN productPrice int, IN productamount int,
                                                   IN productdescription varchar(50))
begin
	insert into products(productcode, productname, productprice, productamount, productdescription)
    values (codes, productname, productprice, productamount, productdescription);
end;

