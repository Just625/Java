create
    definer = root@localhost procedure store_procedure()
begin
	select * from products;
end;

