create
    definer = root@localhost procedure Insert_Customer(IN first_name varchar(255), IN last_name varchar(255))
BEGIN
    INSERT INTO Customer values(first_name, lastName);
end;

